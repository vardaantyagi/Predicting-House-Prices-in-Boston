'use strict';

// Protractor configuration
exports.config = {
  specs: ['modules/*/tests/e2e/*.js']
};
